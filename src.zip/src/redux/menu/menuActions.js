const menuState = (data) => {
    return {
      type: "DISPATCH_MENU_STATE",
      payload: data,
    };
  };
  
  export { menuState };
  