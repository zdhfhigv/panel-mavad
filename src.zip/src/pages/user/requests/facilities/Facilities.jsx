import React from 'react'

function Facilities() {
  return (
    <div>Facilities</div>
  )
}

export default Facilities